import requests
from bs4 import BeautifulSoup
import pandas as pd
import yfinance as yf

def get_canoo_industry_info():
    url = "https://www.technavio.com/report/canoeing-and-kayaking-equipment-market-industry-analysis"
    
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    industry_span = soup.find("span", {"class": "industry"})
    size_span = soup.find("span", {"class": "size"})

    industry = industry_span.text if industry_span else "N/A"
    size = size_span.text if size_span else "N/A"

    industry_info = {
        "industry": industry,
        "size": size,
    }

    return industry_info
   

def get_canoo_competitors_info():
    url = "https://investors.canoo.com/news-presentations/press-releases/detail/45/electric-vehicle-company-canoo-and-hennessy-capital"

    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    competitors_info = []
    competitor_elements = soup.find_all("div", {"class": "competitor"})
    for competitor_element in competitor_elements:
        competitor_info = {
            "name": competitor_element.find("span", {"class": "name"}).text,
            "market_share": competitor_element.find("span", {"class": "market-share"}).text,
        }
        competitors_info.append(competitor_info)

    return competitors_info

def get_canoo_financial_data():
    ticker = "GOEV"  
    canoo_stock = yf.Ticker(ticker)
    financial_data = canoo_stock.history(period="1d", start="2023-01-01", end="2024-01-01")

    return financial_data

def save_to_csv(data, filename):
    data.to_csv(filename, index=False)

if __name__ == "__main__":
    canoo_industry_info = get_canoo_industry_info()
    print("Canoo Industry Info:", canoo_industry_info)

    canoo_competitors_info = get_canoo_competitors_info()
    print("Canoo Competitors Info:", canoo_competitors_info)

    canoo_financial_data = get_canoo_financial_data()
    print("Canoo Financial Data:")
    print(canoo_financial_data)

    save_to_csv(canoo_financial_data, "canoo_financial_data.csv")
